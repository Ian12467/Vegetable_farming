package com.example.mkulima_plus.Isaka
class Isaka_DataClass(
    val name:String?="",
    val AttackBio:String?="",
    val images:String?=null
)
