package com.example.mkulima_plus.Managu

class Crops_Dataclass (
    val name:String?="",
    val Bio:String?="",
    val treatment:String?="",
    val images:String?=null
)



