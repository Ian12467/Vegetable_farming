package com.example.mkulima_plus.View

import android.os.Parcel
import android.os.Parcelable

data class cropsModel(val images:Int, val textname: String?)
{

}


