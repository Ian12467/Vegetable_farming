package com.example.mkulima_plus.Isaka

class Isaka_Tips_DataClass (
//val name:String?="",
val AttackBio:String?="",
val images:String?=null,
val stage:String? ="",
)
